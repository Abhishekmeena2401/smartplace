// =============================================
//   RESUME ANALYZER - EXPRESS BACKEND
//   Simple beginner-friendly code
// =============================================

const express = require('express');
const multer = require('multer');       // for handling file uploads
const pdfParse = require('pdf-parse'); // for extracting text from PDF
const axios = require('axios');         // for calling OpenAI API
const cors = require('cors');           // to allow frontend to connect

const app = express();
const PORT = 3000;

// ---- SETUP ----

// Allow requests from frontend (CORS)
app.use(cors());

// Use memory storage - file is kept in RAM, not saved to disk
const upload = multer({ storage: multer.memoryStorage() });


// ---- MAIN ROUTE ----

// POST /analyze
// 1. Receive the PDF file
// 2. Extract text from PDF
// 3. Send text to OpenAI
// 4. Return the result

app.post('/analyze', upload.single('resume'), async (req, res) => {

  // Step 1: Check if file was uploaded
  if (!req.file) {
    return res.json({ error: 'No file uploaded. Please send a PDF file.' });
  }

  try {

    // Step 2: Extract text from the PDF buffer
    console.log('Extracting text from PDF...');
    const pdfData = await pdfParse(req.file.buffer);
    const resumeText = pdfData.text;

    if (!resumeText || resumeText.trim().length === 0) {
      return res.json({ error: 'Could not extract text from this PDF. Make sure it is not a scanned image.' });
    }

    console.log('Text extracted. Sending to OpenAI...');

    // Step 3: Send to OpenAI
    const openaiResponse = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: `Here is a resume. Please analyze it and give me:
1. An ATS (Applicant Tracking System) score out of 100
2. Suggestions to improve this resume
3. Skills I should learn in the future based on this resume
4. Project ideas I should build to strengthen my profile

Resume:
${resumeText}`
          }
        ],
        max_tokens: 1500
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,  // Set this in your environment
          'Content-Type': 'application/json'
        }
      }
    );

    // Step 4: Get the AI reply and send it to frontend
    const aiReply = openaiResponse.data.choices[0].message.content;
    console.log('Got response from OpenAI!');

    res.json({ result: aiReply });

  } catch (err) {
    // If anything goes wrong, send back the error message
    console.error('Error:', err.message);

    if (err.response) {
      // This means OpenAI returned an error
      return res.json({ error: 'OpenAI API error: ' + err.response.data.error.message });
    }

    res.json({ error: 'Something went wrong: ' + err.message });
  }

});


// ---- START SERVER ----

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
  console.log(`📌 Make sure to set your OPENAI_API_KEY before starting`);
});
